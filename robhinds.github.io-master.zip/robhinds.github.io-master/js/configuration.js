var CONFIGURATION.links = [
	{ title: "", url: "" }
];
